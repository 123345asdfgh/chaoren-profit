import {readFile} from 'node:fs/promises';
import {pool} from './db.js';
try{await pool.query(await readFile(new URL('./schema.sql',import.meta.url),'utf8'));console.log('profit schema ready in chaoren_profit_dev')}
finally{await pool.end()}
