import type {Metadata} from 'next';
export const metadata:Metadata={title:'跨境利润测算 · chaoren AI'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="zh-CN"><body style={{margin:0}}>{children}</body></html>}
